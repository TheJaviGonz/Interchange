<!DOCTYPE HTML>
<!--
	Strata by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?php

session_start();
putenv('TZ=Europe/Madrid');
$fecha1 = date("l F ");
$fecha2 = date("Y-m-d");

$inicio=$_SESSION['nick'];

?>
<html>
	<head>
		<title>Strata by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->

		<link rel="shortcut icon" href="../favicon.ico">		
		<link rel="stylesheet" type="text/css" href="css/set1.css" />
	</head>
	<body id="top">

		<!-- Header -->
			<header id="header">
				<a href="#" class="image avatar"><img src="images/OnDJPNG.png" alt="" /></a>
				<h1>Bienvenido,<strong> <?php echo $_SESSION['nick'];  ?></strong><br />
				al entorno para DJ's<br />
				</h1>
			</header>

		<!-- Main -->
			<div id="main">

				<!-- One -->
					<section id="one">
						<header class="major">
							<h2>En este espacio podras consultar las peticiones de las personas, sobre canciones que quieren escuchar</h2>
						</header>
						<p>Ayudate de este soporte para exprimir al maximo la diversion y una noche de fiesta para entretener a todas las personas de tu alrededor tan solo con nuestra aplicacion movil y el soporte para ti</p>
	
					</section>

				<!-- Two -->
					<section id="two">
						<h2>Opciones</h2>
						<div class="row">

				<div class="grid">
					<figure class="effect-zoe">
						<a href="./peticiones/index.php"><img src="img/canciones.png"  alt="img25"/></a>
						<figcaption>
							<h2>Lista  de  Canciones</h2>
							<br/>
						</figcaption>			
					</figure>
					<figure class="effect-zoe">
						<img src="img/Estadisticas.png" alt="img26"/>
						<figcaption>
							<h2>Estadísticas</h2>

							
						</figcaption>			
					</figure>
		
			
					<figure class="effect-zoe">
						<a href="./peticiones/index.php"><img src="img/Peticiones.png"  alt="img25"/></a>
						<figcaption>
							<h2>Peticiones</h2>
							<br/>
					
						</figcaption>			
					</figure>
					<figure class="effect-zoe">
						<img src="img/Play.png" alt="img26"/>
						<figcaption>
							<h2>En  directo</h2>

							
						</figcaption>			
					</figure>
				</div>
						
						
						
						
							
			
		<!-- Footer -->
			<footer id="footer">
				<ul class="icons">
					<li><a href="https://twitter.com/OnDJ_Inc" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="https://www.facebook.com/ondjapp?fref=ts" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
				</ul>
				<ul class="copyright">
							<li>&copy; OnDJ 2015</li><li>Todos los derechos reservados</li>
							<li>Universidad de Alcalá</li>
				</ul>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>